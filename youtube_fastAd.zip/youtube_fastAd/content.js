function checkAds() {
    const video = document.querySelector('video');
    if (video) {
        const adPlaying = video.duration > 0 && video.currentTime < video.duration && document.querySelector('.ad-showing');
        if (adPlaying) {
            video.playbackRate = 16; //play ad in 16x
        } else {
            video.playbackRate = 1; // go back to 1x when video is playing
        }
    }
}

setInterval(checkAds, 100); // repeat for every 0.1s